package com.centurylink.kotlin.script

import java.io.File

class KotlinClasspath {
    
    val asFiles: List<File> by lazy {
        var files = mutableListOf<File>()
		// TODO 
        files.add(File("e:/workspaces/mdw6/mdw-workflow/assets"))
		// TODO compiled kotlin
		files.add(File("e:/workspaces/mdw6/mdw/temp/kotlin/classes"))
        files.addAll(File("e:/workspaces/KotlinRig/lib").listFiles())
        files
    }
    
    val asString: String by lazy {
        asFiles.joinToString(File.pathSeparator)
    }
}