package com.centurylink.testing.kotlin;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import org.jetbrains.kotlin.cli.common.ExitCode;
import org.jetbrains.kotlin.cli.jvm.K2JVMCompiler;

import com.centurylink.kotlin.script.KotlinClasspath;
import com.centurylink.kotlin.script.KotlinScriptEngine;
import com.centurylink.kotlin.script.KotlinScriptEngineFactory;

public class ScriptEngineAccess {
    
    private static ScriptEngineAccess instance;
    public static ScriptEngineAccess getInstance() {
        if (instance == null)
            throw new IllegalStateException("ScriptEngineAccess startup failed?");
        return instance;
    }

    private KotlinScriptEngine scriptEngine;
    public KotlinScriptEngine getScriptEngine() {
        if (scriptEngine == null)
            scriptEngine = (KotlinScriptEngine) new KotlinScriptEngineFactory().getScriptEngine();
        return scriptEngine;
    }
    
    public void onStartup() {
        
        // TODO CodeTimer
        // If scriptEngine instantiation is slow, consider delaying in dev
        getScriptEngine();
        
        try {
            // compile .kt assets (not scripts)
            List<File> sources = getSources();
            if (!sources.isEmpty()) {
                String classpath = new KotlinClasspath().getAsString();
                // TODO debug
                System.out.println("CLASSPATH: " + classpath);
                
                String sourcesArg = "";
                // TODO mdwDebug
                System.out.println("SOURCES:");
                for (int i = 0; i < sources.size(); i++) {
                    // TODO mdwDebug
                    System.out.println("  " + sources.get(i));
                    if (i > 0)
                        sourcesArg += " ";
                    sourcesArg += sources.get(i); 
                }
                
                ExitCode exitCode = new K2JVMCompiler().exec(
                    System.out,
                    sourcesArg,
                    "-d", "e:/workspaces/mdw6/mdw/temp/kotlin/classes",
                    "-no-stdlib",
                    "-classpath", classpath
                );
                // TODO logger
                System.out.println("EXIT: " + exitCode.getCode());
            }
            
            instance = this; 
        }
        catch (Exception ex) {
            // TODO StartupException
            throw new RuntimeException("Kotlin initialization failure: " + ex.getMessage(), ex);
        }
        
    }
    
    private List<File> getSources() throws IOException {
        // TODO AppContext
        Path assetRoot = Paths.get(new File("e:/workspaces/mdw6/mdw-workflow/assets").getPath().replace('\\', '/'));
        
        // TODO Package
        Path omitPath = Paths.get(new File("e:/workspaces/mdw6/mdw-workflow/assets/com/centurylink/mdw/kotlin/").getPath());
        
        PathMatcher ktMatcher = FileSystems.getDefault().getPathMatcher("glob:**/*.kt");
        List<File> files = new ArrayList<>();
        Files.walkFileTree(assetRoot,
            EnumSet.of(FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE, new SimpleFileVisitor<Path>() {
                public FileVisitResult visitFile(Path path, BasicFileAttributes attrs) throws IOException {
                    if (ktMatcher.matches(path) && !path.startsWith(omitPath)) {
                        files.add(path.toFile());
                    }
                    return FileVisitResult.CONTINUE;
                }
            }
        );
        return files;
    }
    
}
