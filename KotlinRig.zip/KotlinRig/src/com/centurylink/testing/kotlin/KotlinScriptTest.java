package com.centurylink.testing.kotlin;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.centurylink.mdw.tests.script.Person;

public class KotlinScriptTest {

    public static void main(String[] args) {
        
        try {
            
            // init script engine access
            new ScriptEngineAccess().onStartup();
            
            String script = new String(Files.readAllBytes(Paths.get(new File("scripts/ExecScript.kts").getPath())));
            
            Map<String,String> types = new HashMap<>();
            types.put("testCase", "java.lang.String");
            types.put("person", "io.limberest.json.Jsonable");
            
            Map<String,Object> bindings = new HashMap<>();
            bindings.put("testCase", "exec");
            JSONObject personJson = new JSONObject();
            personJson.put("firstName", "Linus");
            personJson.put("lastName", "Torvalds");
            Person person = new Person(personJson);
            bindings.put("person", person);
            
            
            KotlinExecutor exec = new KotlinExecutor();
            
            exec.setName("ExecScript");
            exec.execute(script, bindings, types);
            
//            KotlinEvaluator eval = new KotlinEvaluator();
//            eval.setName("hello");
//            Object ret = eval.evaluate("testCase", bindings, types);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
