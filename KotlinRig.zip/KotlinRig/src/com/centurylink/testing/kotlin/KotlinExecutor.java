package com.centurylink.testing.kotlin;

import java.util.Map;

import javax.script.ScriptException;

import org.jetbrains.kotlin.cli.common.repl.KotlinJsr223JvmScriptEngineBase.CompiledKotlinScript;

import com.centurylink.kotlin.script.KotlinScriptEngine;

public class KotlinExecutor {

    private String name;
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // TODO cache precompiled scripts

    public Object execute(String script, Map<String,Object> bindings)
            throws ExecutionException {
        return execute(script, bindings, null);
    }

    public Object execute(String script, Map<String,Object> bindings, Map<String,String> types)
            throws ExecutionException {
        try {
            KotlinScriptEngine engine = ScriptEngineAccess.getInstance().getScriptEngine();
            for (String bindName : bindings.keySet()) {
                engine.put(bindName, bindings.get(bindName));
            }
            CompiledKotlinScript compiled = (CompiledKotlinScript) engine.compile(script, bindings, types);
            return engine.eval(compiled);
        }
        catch (ScriptException ex) {
            throw new ExecutionException("Kotlin error: " + ex.getMessage(), ex);
        }
    }
}
